varying vec4 _color;

void main() {
  ${out: color} = _color;
}
