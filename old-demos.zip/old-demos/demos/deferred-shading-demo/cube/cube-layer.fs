varying vec2 _texCoord;
varying vec4 _color;

void main() {
  ${out: color} = _color;
}
