export * from "./deferred-shading-demo";
